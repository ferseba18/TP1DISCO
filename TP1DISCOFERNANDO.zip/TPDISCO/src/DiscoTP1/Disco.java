package DiscoTP1;


public class Disco {
	
	private Double radioInterior;
	private Double radioExterior;
	private Double perimetroInterior;
	private Double perimetroExterior;
	private Double superficie;
	
	public Disco(Double radioInterior, Double radioExterior){
		
		this.radioInterior=radioInterior;
		this.radioExterior=radioExterior;
		
		this.perimetroInterior= 2*Math.PI*radioInterior;
		this.perimetroExterior= 2*Math.PI*radioExterior;

}
	public Double getperimetroInterior()
	{
		return this.perimetroInterior;
	}
	
	public Double getperimetroExterior()
	{
		return this.perimetroExterior;
	}

}