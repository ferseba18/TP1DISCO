package DiscoTest;
import org.junit.Assert;
import org.junit.Test;

import DiscoTP1.Disco;

public class DiscoTest {

	@Test
	public void testParaCalcularPerimetroInterior() {
		
		Disco DiscoPrueba = new Disco(8.00,9.00);
		Double perimetroInteriorEsperado= 8.00*Math.PI*2;
		Double perimetroInteriorObtenido= DiscoPrueba.getperimetroInterior();
		Assert.assertEquals(perimetroInteriorEsperado, perimetroInteriorObtenido);
	}
	
	@Test
	public void testParaCalcularPerimetroExterior() {
		
		Disco DiscoPrueba = new Disco(6.00,7.00);
		Double perimetroExteriorEsperado= 7.00*Math.PI*2;
		Double perimetroExteriorObtenido= DiscoPrueba.getperimetroExterior();
		Assert.assertEquals(perimetroExteriorEsperado, perimetroExteriorObtenido);
	}
	

}
